package com.example.slidingattendancecalculator;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class FragmentCollectionAdaptor extends FragmentStatePagerAdapter {

    public FragmentCollectionAdaptor(FragmentManager fm)
    {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new AttendanceFragment();
            case 1:
                return new ViewAttendanceFragment();
            case 2:
                return new StatisticAttendanceFragment();
            default:
                return null;
        }
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return "Page " + position;
    }

    @Override
    public int getCount() {
        return 3;
    }
}
