package com.example.attendancecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class AttendanceActivity extends AppCompatActivity {

    private TextView tv1;
    private DatabaseHelper db;
    private Cursor res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        getTable();
    }

    private void getTable(){
        db = new DatabaseHelper(this);
        res = db.getData();
        TableLayout ll = findViewById(R.id.displayLinear);
        String[] arr = {"Date", "JPL", "OSL", "DBMSL", "JAVA", "OS", "DBMS", "BEFA", "COI", "DM"};

        TableRow titleRow= new TableRow(this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        titleRow.setLayoutParams(lp);
        for(int j=0;j<arr.length;j++){
                TextView tv = new TextView(this);
                tv.setText("\t"+arr[j]+" ");
                titleRow.addView(tv);
            }
        ll.addView(titleRow, 0);
        int i = 1;
        while (res.moveToNext()){
            TableRow row= new TableRow(this);
            //TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(lp);
            for(int j=0;j<arr.length;j++){
                tv1 = new TextView(this);
                tv1.setText("\t" + res.getString(j+1) + " ");
                row.addView(tv1);
            }
            ll.addView(row, i);
            i++;
        }


    }
}
