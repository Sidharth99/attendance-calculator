package com.example.attendancecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class StatsActivity extends AppCompatActivity {

//    int[] mon_att    = {4,0,0,1,1,0,0,0,1};
//    int[] tue_att    = {0,0,0,1,0,2,2,1,1};
//    int[] wed_att    = {0,0,3,1,1,0,1,1,0};
//    int[] thurs_att  = {0,4,0,1,0,1,0,0,1};
//    int[] fri_att    = {0,0,0,1,2,1,1,0,2};
//    int[] sat_att    = {0,0,0,1,2,2,1,1,0};

    int total_attended, total_classes_held;
    int jpl, osl, dbmsl, jav, os, dbms, befa, coi, dm;
    int count;
    float percentage;
    DatabaseHelper db;
    Cursor res;
    //int datee;
    int j;
    int attByDate;

    BarChart barChart;
    BarData barData;
    BarDataSet barDataSet;
    ArrayList barEntries;
    ArrayList<String> xAxisLabel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        db = new DatabaseHelper(this);
        res = db.getData();
        total_attended=0;
        count = res.getCount();
        barEntries = new ArrayList<>();
        xAxisLabel = new ArrayList<>();
        //dateArr = new int[count];
        //attByDate = new int[count];

        if(count>0){
            j=0;
            while (res.moveToNext()){
                attByDate = 0;
                for(int i=2;i<11;i++){
                    int val = res.getInt(i);
                    total_attended += val;
                    attByDate += val;
                }

                jpl += res.getInt(2);
                osl += res.getInt(3);
                dbmsl += res.getInt(4);
                jav += res.getInt(5);
                os += res.getInt(6);
                dbms += res.getInt(7);
                befa += res.getInt(8);
                coi += res.getInt(9);
                dm += res.getInt(10);

                xAxisLabel.add(res.getString(1));

                //datee = Integer.parseInt(res.getString(1).split("-")[0]);
                //Log.d("Date", res.getString(1).split("-")[0]);
                //Log.d("Attendance", String.valueOf(attByDate));
                barEntries.add(new BarEntry(j , attByDate));
                j++;

            }
            total_classes_held = count * 7;
            percentage = total_attended*100/total_classes_held;
        }
        TextView tv = findViewById(R.id.totalAtt);
        tv.setText("Total classes held: "+total_classes_held+"\nTotal classes attended: "+total_attended+"\nPercentage: "+percentage+"\nJPL: "+jpl+"\nDBMSL: "+dbmsl+"\nOSL: "+osl+"\nJAVA: "+jav+"\nOS: "+os+"\nDBMS: "+dbms+"\nBEFA: "+befa+"\nCOI: "+coi+"\nDM: "+dm);

        getGraph();

    }

//    private void getEntries() {
//
//        barEntries.add(new BarEntry(27, 7));
//        barEntries.add(new BarEntry(26, 6));
//        barEntries.add(new BarEntry(25, 7));
//        barEntries.add(new BarEntry(24, 4));
//        barEntries.add(new BarEntry(23, 6));
//        barEntries.add(new BarEntry(22, 0));
//        barEntries.add(new BarEntry(21, 7));
//        barEntries.add(new BarEntry(20, 6));
//        barEntries.add(new BarEntry(19, 7));
//        barEntries.add(new BarEntry(18, 4));
//        barEntries.add(new BarEntry(16, 6));
//
//    }

    private void getGraph(){
        barChart = findViewById(R.id.BarChart);
        //getEntries();
        barDataSet = new BarDataSet(barEntries, "");
        barData = new BarData(barDataSet);
        barChart.setData(barData);

        final XAxis xAxis = barChart.getXAxis();
        xAxis.setLabelRotationAngle(0f);
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return xAxisLabel.get((int) value);
            }
        });

        barDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(18f);
    }
}
