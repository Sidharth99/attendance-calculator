package com.example.slidingattendancecalculator;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "student.db";
    public static final String TABLE_NAME = "student_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "DATEE";
    public static final String COL_3 = "JPL";
    public static final String COL_4 = "OSL";
    public static final String COL_5 = "DBMSL";
    public static final String COL_6 = "JAVA";
    public static final String COL_7 = "OS";
    public static final String COL_8 = "DBMS";
    public static final String COL_9 = "BEFA";
    public static final String COL_10 = "COI";
    public static final String COL_11 = "DM";
    public DatabaseHelper(@Nullable Context context ) {
        super(context, DATABASE_NAME, null, 1);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,DATEE date, JPL INTEGER, OSL INTEGER, DBMSL INTEGER, JAVA INTEGER, OS INTEGER, DBMS INTEGER, BEFA INTEGER, COI INTEGER, DM INTEGER)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String date, int jpl, int osl, int dbmsl, int java, int os, int dbms, int befa, int coi, int dm){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_2, date);
        contentValues.put(COL_3, jpl);
        contentValues.put(COL_4, osl);
        contentValues.put(COL_5, dbmsl);
        contentValues.put(COL_6, java);
        contentValues.put(COL_7, os);
        contentValues.put(COL_8, dbms);
        contentValues.put(COL_9, befa);
        contentValues.put(COL_10, coi);
        contentValues.put(COL_11, dm);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return (result!=-1);
    }

    public boolean dateExists(String date){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cr = db.rawQuery("SELECT DATEE FROM student_table ORDER BY id DESC LIMIT 1", null);
        Log.d("cursor: ", String.valueOf(cr.getCount()));
        if(cr.getCount()==0){
            return false;
        }
        cr.moveToNext();
        String str = cr.getString(0);
        return str.equals(date);
        //return false;
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cr = db.rawQuery("SELECT * FROM student_table ORDER By id DESC", null);
        return cr;
    }
}
