package com.example.slidingattendancecalculator;


import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class ViewAttendanceFragment extends Fragment {


    private DatabaseHelper db;
    private Cursor res;
    private TextView tv1;
    Context context;
    public ViewAttendanceFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_view_attendance, container, false);
        context = view.getContext();
        db = new DatabaseHelper(context);
        res = db.getData();
        TableLayout ll = view.findViewById(R.id.displayLinear);
        String[] arr = {"Date", "JPL", "OSL", "DBMSL", "JAVA", "OS", "DBMS", "BEFA", "COI", "DM"};

        TableRow titleRow= new TableRow(context);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        titleRow.setLayoutParams(lp);
        for(int j=0;j<arr.length;j++){
            TextView tv = new TextView(context);
            tv.setText("\t"+arr[j]+" ");
            titleRow.addView(tv);
        }
        ll.addView(titleRow, 0);
        int i = 1;
        while (res.moveToNext()){
            TableRow row= new TableRow(context);
            //TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(lp);
            for(int j=0;j<arr.length;j++){
                tv1 = new TextView(context);
                tv1.setText("\t" + res.getString(j+1) + " ");
                row.addView(tv1);
            }
            ll.addView(row, i);
            i++;
        }


        return view;
    }

}
