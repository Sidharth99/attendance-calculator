package com.example.attendancecalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    //static int k;
    DatabaseHelper myDb;

    static int[] att = {0,0,0,0,0,0,0,0,0};


    final String[] periods = {"JPL", "OSL", "DBMSL", "JAVA", "OS", "DBMS", "BEFA", "COI", "DM"};
    static final String[][] arr = {{"Sunday", "Holiday",  "Holiday",  "Holiday",  "Holiday",  "Holiday",  "Holiday",  "Holiday"},{"Monday","JPL", "JPL", "JPL", "JPL", "OS", "JAVA", "DM"},{"Tuesday", "DBMS", "JAVA", "BEFA", "DM", "DBMS", "BEFA", "COI"}, {"Wednesday", "COI", "BEFA", "JAVA", "OS", "DBMSL", "DBMSL", "DBMSL"}, {"Thursday", "OSL", "OSL", "OSL", "OSL", "JAVA", "DM", "DBMS"}, {"Friday", "DM", "OS", "DBMS", "JAVA", "DM", "OS", "BEFA"}, {"Saturday","OS", "DBMS", "BEFA", "OS", "DBMS", "JAVA", "COI"}};
    Date date = new Date();
    String modifiedDate= new SimpleDateFormat("dd-MM-yyyy").format(date);
    int i;
    private int myday ;
    private Button insertData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button[] btns = {(Button) findViewById(R.id.button1), (Button) findViewById(R.id.button2), (Button) findViewById(R.id.button3), (Button) findViewById(R.id.button4), (Button) findViewById(R.id.button5), (Button) findViewById(R.id.button6), (Button) findViewById(R.id.button7)};


        myDb = new DatabaseHelper(this);
        insertData = (Button) findViewById(R.id.insertData);

        boolean dateExist = myDb.dateExists(modifiedDate);

        Calendar c  = Calendar.getInstance();
        myday = c.get(Calendar.DAY_OF_WEEK);
        TextView dayString = (TextView) findViewById(R.id.dayString);
        dayString.setText(arr[myday-1][0]);
        for(i = 1; i<arr[myday-1].length; i++){
            final Button btn = (Button)findViewById(getResources().getIdentifier("button" + i, "id",
                    this.getPackageName()));
            TextView tv = (TextView) findViewById(getResources().getIdentifier("textView" + i, "id",
                    this.getPackageName()));

            if(myday==1){
                //Toast.makeText(getApplicationContext(),"Hello day 1",Toast.LENGTH_SHORT).show();
                btn.setVisibility(View.INVISIBLE);
                tv.setVisibility(View.INVISIBLE);
            }else{
                //Toast.makeText(getApplicationContext(),"Hello else",Toast.LENGTH_SHORT).show();
                tv.setText(arr[myday-1][i]);
                btn.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                btn.setTextColor(getResources().getColor(R.color.presentColor));

            }
            if(dateExist){
               btn.setEnabled(false);
               btn.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
               insertData.setEnabled(false);
            }


        }

        //addData();
        //for(int j=0;j<btns.length;j++){
            btns[0].setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int idx = getIndex(periods, arr[myday-1][1]);
                            att[idx] += 1;
                            btns[0].setEnabled(false);
                            btns[0].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                            Log.d("idx:", String.valueOf(idx));
                            Log.d("arrval", arr[myday-1][1]);
                        }
                    }
            );
        btns[1].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][2]);
                        att[idx] += 1;
                        btns[1].setEnabled(false);
                        btns[1].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][2]);
                    }
                }
        );
        btns[2].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][3]);
                        att[idx] += 1;
                        btns[2].setEnabled(false);
                        btns[2].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][3]);
                    }
                }
        );
        btns[3].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][4]);
                        att[idx] += 1;
                        btns[3].setEnabled(false);
                        btns[3].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][4]);
                    }
                }
        );
        btns[4].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][5]);
                        att[idx] += 1;
                        btns[4].setEnabled(false);
                        btns[4].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][5]);
                    }
                }
        );
        btns[5].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][6]);
                        att[idx] += 1;
                        btns[5].setEnabled(false);
                        btns[5].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][6]);
                    }
                }
        );
        btns[6].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][7]);
                        att[idx] += 1;
                        btns[6].setEnabled(false);
                        btns[6].setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][7]);
                    }
                }
        );
       // }
        InsertData();

    }

    public void InsertData() {
        insertData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        boolean isInserted = myDb.insertData(modifiedDate, att[0], att[1], att[2], att[3], att[4], att[5], att[6], att[7], att[8]);
                        if(isInserted){
                            Toast.makeText(getApplicationContext(), "Submitted Successfully", Toast.LENGTH_SHORT).show();
                            insertData.setTextColor(getResources().getColor(R.color.colorAccent));
                            insertData.setEnabled(false);
                        }else{
                            Toast.makeText(getApplicationContext(), "Error occured. Please inform to developer.", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
        );

    }

    private int getIndex(String arr[], String s){
        for(int j=0;j<arr.length;j++){
            if(s.equals(arr[j])){
                return j;
            }
        }
        return -1;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent intent;
        switch (item.getItemId()){
            case R.id.mainMenuAbout:
                Toast.makeText(this, "About", Toast.LENGTH_SHORT).show();
                new AlertDialog.Builder(this)
                        .setTitle("About")
                        .setMessage("Welcome to my app.\nClick on present and submit it to add the attendance.\nAlso note that you must submit it even when you are absent to get accurate percentage.\nNo need to submit on holidays.\nAll suggestions are welcome.\nI am currently working on its UI as it sucks as of now.\n\t\t\t\t\tTHANK YOU\n\t\t\t\t\t\t\t\t\t\t\t\t\t-Sidharth Jain")

                        // Specifying a listener allows you to take an action before dismissing the dialog.
                        // The dialog is automatically dismissed when a dialog button is clicked.
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with delete operation
                            }
                        })

                        // A null listener allows the button to dismiss the dialog and take no further action.
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return true;
            case R.id.mainMenuAttendance:
                intent = new Intent(this, AttendanceActivity.class);
                Toast.makeText(this, "Attendance", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                return true;
            case R.id.mainMenuStats:
                intent = new Intent(this, StatsActivity.class);
                Toast.makeText(this, "Stats", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                return true;
            case R.id.mainMenuExit:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /*
    public void addData(){
        Button btn;
        for(int j=1;j<arr[myday-1].length;j++){
            btn = (Button)findViewById(getResources().getIdentifier("button" + j, "id",
                    this.getPackageName()));
            final Button finalBtn = btn;
            k=j;
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("j:", String.valueOf(k));
                    int idx = getIndex(periods, arr[myday-1][k]);
                    Log.d("idx:", String.valueOf(idx));
                    Log.d("arrval", arr[myday-1][k]);
                    att[idx-1] += 1;
                    finalBtn.setEnabled(false);
                }
            });
        }
    }
    */




}

