package com.example.slidingattendancecalculator;

import androidx.appcompat.app.AppCompatActivity;

import androidx.viewpager.widget.ViewPager;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private FragmentCollectionAdaptor adaptor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        new AlertDialog.Builder(this)
                .setTitle("About")
                .setMessage("Welcome to my app.\nClick on present and submit it to add the attendance.\nAlso note that you must submit it even when you are absent to get accurate percentage.\nNo need to submit on holidays.\nAll suggestions are welcome.\nI am currently working on its UI as it sucks as of now.\n\t\t\t\t\tTHANK YOU\n\t\t\t\t\t\t\t\t\t\t\t\t\t-Sidharth Jain")

                // Specifying a listener allows you to take an action before dismissing the dialog.
                // The dialog is automatically dismissed when a dialog button is clicked.
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Continue with delete operation
                    }
                })

                // A null listener allows the button to dismiss the dialog and take no further action.
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
        viewPager = findViewById(R.id.pagerViewer);
        adaptor = new FragmentCollectionAdaptor(getSupportFragmentManager());
        viewPager.setAdapter(adaptor);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                String arr[] = {"Home", "Attendance", "Stats"};
                getSupportActionBar().setTitle(arr[position]);

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
}
