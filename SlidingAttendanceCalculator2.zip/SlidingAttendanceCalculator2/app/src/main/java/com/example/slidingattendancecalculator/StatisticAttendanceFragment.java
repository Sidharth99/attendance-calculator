package com.example.slidingattendancecalculator;


import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class StatisticAttendanceFragment extends Fragment {

    int total_attended, total_classes_held;
    int jpl, osl, dbmsl, jav, os, dbms, befa, coi, dm;
    int count;
    float percentage;
    DatabaseHelper db;
    Cursor res;
    //int datee;
    int j;
    int attByDate;

    BarChart barChart;
    BarData barData;
    BarDataSet barDataSet;
    ArrayList barEntries;
    ArrayList<String> xAxisLabel;
    public StatisticAttendanceFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_statistic_attendance, container, false);
        db = new DatabaseHelper(view.getContext());
        res = db.getData();
        total_attended=0;
        count = res.getCount();
        barEntries = new ArrayList<>();
        xAxisLabel = new ArrayList<>();

        if(count>0){
            j=0;
            while (res.moveToNext()){
                attByDate = 0;
                for(int i=2;i<11;i++){
                    int val = res.getInt(i);
                    total_attended += val;
                    attByDate += val;
                }

                jpl += res.getInt(2);
                osl += res.getInt(3);
                dbmsl += res.getInt(4);
                jav += res.getInt(5);
                os += res.getInt(6);
                dbms += res.getInt(7);
                befa += res.getInt(8);
                coi += res.getInt(9);
                dm += res.getInt(10);

                xAxisLabel.add(res.getString(1));

                //datee = Integer.parseInt(res.getString(1).split("-")[0]);
                //Log.d("Date", res.getString(1).split("-")[0]);
                //Log.d("Attendance", String.valueOf(attByDate));
                barEntries.add(new BarEntry(j , attByDate));
                j++;

            }
            total_classes_held = count * 7;
            percentage = total_attended*100/total_classes_held;
        }

        barChart = view.findViewById(R.id.BarChart);
        //getEntries();
        barDataSet = new BarDataSet(barEntries, "");
        barData = new BarData(barDataSet);
        barChart.setData(barData);

        final XAxis xAxis = barChart.getXAxis();
        xAxis.setLabelRotationAngle(0f);
        xAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return xAxisLabel.get((int) value);
            }
        });

        barDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(18f);

        TextView tv = view.findViewById(R.id.totalAtt);
        tv.setText("Total classes held: "+total_classes_held+"\nTotal classes attended: "+total_attended+"\nPercentage: "+percentage+"\njpl: "+jpl+"\ndbmsl: "+dbmsl+"\nosl: "+osl+"\njava: "+jav+"\nOS: "+os+"\nDBMS: "+dbms+"\nBEFA: "+befa+"\nCOI: "+coi+"\nDM: "+dm);
        return view;
    }

}
