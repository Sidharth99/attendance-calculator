package com.example.slidingattendancecalculator;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 */
public class AttendanceFragment extends Fragment {

    //static int k;
    DatabaseHelper myDb;

    static int[] att = {0,0,0,0,0,0,0,0,0};
    final String[] periods = {"JPL", "OSL", "DBMSL", "JAVA", "OS", "DBMS", "BEFA", "COI", "DM"};
    static final String[][] arr = {{"Sunday", "Holiday",  "Holiday",  "Holiday",  "Holiday",  "Holiday",  "Holiday",  "Holiday"},{"Monday","JPL", "JPL", "JPL", "JPL", "OS", "JAVA", "DM"},{"Tuesday", "DBMS", "JAVA", "BEFA", "DM", "DBMS", "BEFA", "COI"}, {"Wednesday", "COI", "BEFA", "JAVA", "OS", "DBMSL", "DBMSL", "DBMSL"}, {"Thursday", "OSL", "OSL", "OSL", "OSL", "JAVA", "DM", "DBMS"}, {"Friday", "DM", "OS", "DBMS", "JAVA", "DM", "OS", "BEFA"}, {"Saturday","OS", "DBMS", "BEFA", "OS", "DBMS", "JAVA", "COI"}};
    Date date = new Date();
    String modifiedDate= new SimpleDateFormat("dd-MM-yyyy").format(date);
    int i;
    private int myday ;
    private Button insertData;

    public AttendanceFragment() {

        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_attendance, container, false);

        final Button[] btns = {(Button) view.findViewById(R.id.button1), (Button) view.findViewById(R.id.button2), (Button) view.findViewById(R.id.button3), (Button) view.findViewById(R.id.button4), (Button) view.findViewById(R.id.button5), (Button) view.findViewById(R.id.button6), (Button) view.findViewById(R.id.button7)};


        myDb = new DatabaseHelper(view.getContext());
        insertData = (Button) view.findViewById(R.id.insertData);

        boolean dateExist = myDb.dateExists(modifiedDate);

        Calendar c  = Calendar.getInstance();
        myday = c.get(Calendar.DAY_OF_WEEK);
        TextView dayString = (TextView) view.findViewById(R.id.dayString);
        dayString.setText(arr[myday-1][0]);
        for(i = 1; i<arr[myday-1].length; i++){
            final Button btn = (Button) view.findViewById(getResources().getIdentifier("button" + i, "id",
                    getActivity().getPackageName()));
            TextView tv = (TextView) view.findViewById(getResources().getIdentifier("textView" + i, "id",
                    getActivity().getPackageName()));

            if(myday==1){
                //Toast.makeText(getApplicationContext(),"Hello day 1",Toast.LENGTH_SHORT).show();
                btn.setVisibility(View.INVISIBLE);
                tv.setVisibility(View.INVISIBLE);
            }else{
                //Toast.makeText(getApplicationContext(),"Hello else",Toast.LENGTH_SHORT).show();
                tv.setText(arr[myday-1][i]);


            }
            if(dateExist){
                btn.setEnabled(false);
                insertData.setEnabled(false);
            }


        }

        //addData();
        //for(int j=0;j<btns.length;j++){
        btns[0].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][1]);
                        att[idx] += 1;
                        btns[0].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][1]);
                    }
                }
        );
        btns[1].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][2]);
                        att[idx] += 1;
                        btns[1].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][2]);
                    }
                }
        );
        btns[2].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][3]);
                        att[idx] += 1;
                        btns[2].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][3]);
                    }
                }
        );
        btns[3].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][4]);
                        att[idx] += 1;
                        btns[3].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][4]);
                    }
                }
        );
        btns[4].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][5]);
                        att[idx] += 1;
                        btns[4].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][5]);
                    }
                }
        );
        btns[5].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][6]);
                        att[idx] += 1;
                        btns[5].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][6]);
                    }
                }
        );
        btns[6].setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int idx = getIndex(periods, arr[myday-1][7]);
                        att[idx] += 1;
                        btns[6].setEnabled(false);

                        Log.d("idx:", String.valueOf(idx));
                        Log.d("arrval", arr[myday-1][7]);
                    }
                }
        );
        // }
        InsertData();

        return view;
    }

    public void InsertData() {
        insertData.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        boolean isInserted = myDb.insertData(modifiedDate, att[0], att[1], att[2], att[3], att[4], att[5], att[6], att[7], att[8]);
                        if(isInserted){
                            Toast.makeText(getContext(), "Successfully inserted data", Toast.LENGTH_SHORT).show();
                            insertData.setEnabled(false);
                        }else{
                            Toast.makeText(getContext(), "Error inserting data", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
        );

    }

    private int getIndex(String arr[], String s){
        for(int j=0;j<arr.length;j++){
            if(s.equals(arr[j])){
                return j;
            }
        }
        return -1;
    }


}
